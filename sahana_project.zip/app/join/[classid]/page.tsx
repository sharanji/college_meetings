import React from "react";

const page = () => {
  return (
    <div className="min-h-screen">
      <iframe
        src="/room.html"
        style={{ height: "97vh", width: "100vw" }}
      ></iframe>
    </div>
  );
};

export default page;
