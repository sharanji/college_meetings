import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  try {
    var response = await prisma.class.findMany();

    return NextResponse.json({
      message: "Success",
      class: response,
    });
  } catch (error) {
    return NextResponse.json(error);
  }
}
