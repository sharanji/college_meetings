import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    var jsonBody = await req.json();
    var response = await prisma.class.create({
      data: {
        userid: Number.parseInt(jsonBody["userId"]),
        className: jsonBody["className"],
      },
    });

    return NextResponse.json({
      message: "created",
      class: response,
    });
  } catch (error) {
    return NextResponse.json(error);
  }
}
