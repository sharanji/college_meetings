"use client";
import React from "react";
import Navbar from "../components/navbar";
const page = () => {
  function submitForm(val: any) {
    console.log(val);
  }
  return (
    <>
      <Navbar />
      <div className="hero min-h-screen bg-base-200">
        <div className="hero-content flex-col lg:flex-row-reverse">
          <div className="text-center lg:text-left">
            <h1 className="text-5xl font-bold">Create a class now</h1>
            <p className="py-6">
              Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda
              excepturi exercitationem quasi. In deleniti eaque aut repudiandae
              et a id nisi.
            </p>
          </div>
          <div className="card shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
            <form className="card-body" onSubmit={(e) => submitForm(e.target)}>
              <div className="form-control">
                <label className="label">
                  <span className="label-text">Class Name</span>
                </label>
                <input
                  type="name"
                  placeholder="Enter the class name"
                  className="input input-bordered"
                  required
                />
              </div>
              <div className="form-control">
                <label className="label">
                  <span className="label-text">Invite Class</span>
                </label>
                <select
                  className="select select-bordered w-full max-w-xs"
                  required
                >
                  <option disabled selected>
                    Who shot first?
                  </option>
                  <option>Han Solo</option>
                  <option>Greedo</option>
                </select>
              </div>
              <div className="form-control">
                <label className="label">
                  <span className="label-text">Date</span>
                </label>
                <input
                  type="datetime-local"
                  placeholder="Select the class date"
                  className="input input-bordered"
                  required
                  value="2018-06-12T19:30"
                  min="2018-06-07T00:00"
                  max="2018-06-14T00:00"
                />
              </div>

              <div className="form-control mt-6">
                <button className="btn btn-primary">Create</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default page;
