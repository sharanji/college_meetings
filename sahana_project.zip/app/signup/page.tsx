"use client";
import Image from "next/image";
import React, { useContext, useState } from "react";
import Swal from "sweetalert2";
import { prisma } from "@/lib/prisma";
import axios from "axios";
import { useRouter } from "next/navigation";
import { AuthContext } from "../providers/authprovider";

type FormData = {
  userName: string;
  password: string;
  userType: number;
};

const LoginPage = () => {
  const router = useRouter();
  const [userType, setUserType] = useState("");
  let loginProvider = useContext<any>(AuthContext);
  const [formData, setFormData] = useState<FormData>({
    userName: "",
    password: "",
    userType: 0,
  });

  async function signup() {
    let _userType: number = userType == "student" ? 1 : 0;
    formData.userType = _userType;

    try {
      var response = await axios.post("/api/signup", formData);
      loginProvider.updateState({
        ...response.data["data"],
        validUser: true,
      });

      localStorage.setItem(
        "login",
        JSON.stringify({
          ...response.data["data"],
          validUser: true,
        })
      );

      Swal.fire({
        title: "good!",
        text: response.data["message"],
        icon: "success",
        confirmButtonText: "Ok",
      }).then(() => {
        router.replace("/");
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error!.toString(),
        icon: "error",
        confirmButtonText: "Ok",
      });
    }
  }

  return (
    <div
      className="row d-flex justify-content-center align-items-center"
      style={{
        height: "80vh",
        width: "100%",
        color: "#00000",
        overflow: "hidden",
      }}
    >
      <div className="col-md-4 align-middle">
        <div className="row d-flex justify-content-center align-items-center">
          <div className="col-12 text-center">
            <Image
              src="/logo.png"
              alt="Vercel Logo"
              className="dark:invert"
              width={80}
              height={80}
            />
          </div>
        </div>
        <label htmlFor="userName">Username</label>
        <input
          type="email"
          id="userName"
          className="form-control"
          onChange={(e) =>
            setFormData({ ...formData, userName: e.target.value })
          }
          placeholder="Enter Your Username"
        />
        <label className="mt-3" htmlFor="Password">
          Password
        </label>
        <input
          type="text"
          id="Password"
          className="form-control"
          onChange={(e) =>
            setFormData({ ...formData, password: e.target.value })
          }
          placeholder="Enter Your Password"
        />
        <label className="mt-3" htmlFor="ConfrimPassword">
          Confrim Password
        </label>
        <input
          type="text"
          id="ConfrimPassword"
          className="form-control"
          placeholder="Enter Your Password"
        />
        <label className="mt-3" htmlFor="user_type">
          Select user Type
        </label>
        <select
          name="user_type"
          id="user_type"
          className="form-control"
          onChange={(e) => setUserType(e.target.value)}
        >
          <option value="">-Select User Type-</option>
          <option value="teacher">Teacher</option>
          <option value="student">Student</option>
        </select>
        {userType == "student" ? (
          <>
            <label className="mt-3" htmlFor="student_class">
              Select your class
            </label>
            <select
              name="student_class"
              id="student_class"
              className="form-control"
              onChange={(e) => setUserType(e.target.value)}
            >
              <option value="">-Select User Type-</option>
              <option value="teacher">Teacher</option>
              <option value="student">Student</option>
            </select>
          </>
        ) : (
          <></>
        )}
        <div className="d-grid gap-2 my-3">
          <button
            className="btn btn-primary"
            type="button"
            onClick={() => {
              signup();
            }}
          >
            SignUp
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
