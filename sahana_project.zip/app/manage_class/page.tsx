"use client";

import React, { useEffect, useRef, useState } from "react";
import Navbar from "../components/navbar";
import { useRouter, useSearchParams } from "next/navigation";
import Classdata from "./components/classdata";
import { Suspense } from "react";
import Loading from "../loading";
import axios from "axios";

const Page = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const classId = searchParams!.get("class_id") ?? "1";
  const [classList, setClasslist] = useState([]);

  useEffect(() => {
    async function fetchClass() {
      var response = await axios.get("/api/class");
      if (response.status == 200) {
        setClasslist(response.data["class"]);
      }
    }
    fetchClass();
  }, [classId]);

  return (
    <>
      <Navbar />

      <div className="min-h-screen p-5">
        <div className="flex justify-center my-3">
          <div className="">
            <button
              className="btn bg-slate-500 hover:bg-cyan-600 mx-1"
              onClick={() => router.push("/manage_class/newclass")}
            >
              Add new class
            </button>
          </div>
        </div>
        <div role="tablist" className="tabs tabs-boxed">
          {classList.map((c: any) => {
            return (
              <a
                key={c.id}
                role="tab"
                className={`tab ${classId == c.id ? "tab-active" : ""}`}
                onClick={() => router.push("?class_id=" + c.id)}
              >
                {c.className}
              </a>
            );
          })}
        </div>

        {classList.length > 0 ? (
          <Suspense fallback={<Loading />}>
            <Classdata></Classdata>
          </Suspense>
        ) : (
          <></>
        )}
      </div>
    </>
  );
};

export default Page;
