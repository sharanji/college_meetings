import React from "react";

const TeacherAnalytics = () => {
  return (
    <div className="row">
      <div className="col-md-6 ">Your class</div>
      <div className="col-md-6">Your your students</div>
    </div>
  );
};

export default TeacherAnalytics;
