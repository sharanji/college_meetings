"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { json } from "stream/consumers";

export const AuthContext = createContext<any>({
  state: {
    userName: "user name",
    validUser: false,
  },
  updateState: null,
});

var isdetailsUpdated = false;
export function AuhProvider({ children }: any) {
  const [loginDetails, setLoginDetails] = useState({
    state: { userName: null, validUser: false },
  });
  useEffect(() => {
    if (!isdetailsUpdated) {
      setLoginDetails(JSON.parse(localStorage.getItem("login")!));
    }
    isdetailsUpdated = true;
  }, []);
  return (
    <AuthContext.Provider
      value={{ state: loginDetails, updateState: setLoginDetails }}
    >
      {children}
    </AuthContext.Provider>
  );
}
