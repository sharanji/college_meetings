import React from "react";

const Loading = () => {
  return <div className="min-h-screen">Please wait...</div>;
};

export default Loading;
