"use client";

import React, { useEffect, useState, useContext, useRef } from "react";
import TeacherAnalytics from "./components/analytics";
import { useRouter } from "next/navigation";
import { AuthContext } from "@/app/providers/authprovider";
import Image from "next/image";
import Navbar from "./components/navbar";

const Dashboard = () => {
  const router = useRouter();

  let loginProvider = useContext<any>(AuthContext);

  function handleAuth() {
    if (!loginProvider.state.validUser) {
      router.push("/login");
    } else {
      loginProvider.updateState({
        userName: "user name",
        validUser: false,
      });
    }
  }

  useEffect(() => {
    console.log(loginProvider);
  });

  return (
    <div className="min-h-screen bg-slate-800">
      <Navbar />
      <div className=" ">
        <div className="grid grid-rows-1 grid-flow-col gap-4 p-5 ">
          <div className="card col-span-1 bg-slate-700 hover:bg-slate-600">
            <div className="text-center">
              <figure className="px-10 pt-10">
                <Image
                  src={"/working.png"}
                  alt="logo"
                  height={100}
                  width={100}
                ></Image>
              </figure>
            </div>
            <div className="card-body items-center text-center">
              <p>Create a class or scheducle</p>
              <div className="card-actions">
                <button
                  className="btn btn-dark"
                  onClick={() => router.push("create_class")}
                >
                  Create Now
                </button>
              </div>
            </div>
          </div>
          <div className="card col-span-1 bg-slate-700 hover:bg-slate-600">
            <div className="text-center">
              <figure className="px-10 pt-10">
                <Image
                  src={"/working.png"}
                  alt="logo"
                  height={100}
                  width={100}
                ></Image>
              </figure>
            </div>
            <div className="card-body items-center text-center">
              {/* <h2 className="card-title">Shoes!</h2> */}
              <p>Manage Students and class</p>
              <div className="card-actions">
                <button
                  onClick={() => router.push("manage_class")}
                  className="btn btn-dark"
                >
                  View Now
                </button>
              </div>
            </div>
          </div>
          <div className="card col-span-1 bg-slate-700 hover:bg-slate-600">
            <div className="text-center">
              <figure className="px-10 pt-10">
                <Image
                  src={"/working.png"}
                  alt="logo"
                  height={100}
                  width={100}
                ></Image>
              </figure>
            </div>
            <div className="card-body items-center text-center">
              {/* <h2 className="card-title">Shoes!</h2> */}
              <p>Your Scheduled classes</p>
              <div className="card-actions">
                <button
                  onClick={() => router.push("scheduled_class")}
                  className="btn btn-dark"
                >
                  See All
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="text-center">
          <p className=" text-pink-600">For Immediate class Join Now</p>
          <button
            onClick={() => router.push("/lobby.html")}
            className="btn btn-primary"
          >
            Join Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
