-- AlterTable
ALTER TABLE "Class" ALTER COLUMN "userid" SET DEFAULT 1;
